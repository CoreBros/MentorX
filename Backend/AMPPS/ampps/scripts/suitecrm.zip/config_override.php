<?php
/***CONFIGURATOR***/
error_reporting(E_PARSE);
$sugar_config['disable_persistent_connections'] = false;
$sugar_config['http_referer']['list'][] = '[[servervar]]';
/***CONFIGURATOR***/