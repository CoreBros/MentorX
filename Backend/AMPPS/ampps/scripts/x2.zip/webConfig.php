<?php
$url='[[softurl]]/'; // Add your server URL here, including any folders the app may be in.  
         // i.e.  www.x2engine.com or www.x2engine.com/x2engine etc. Installer should do this manually.
         // Note that this is used as the default base URL for tracking image URLs when
         // there is no session/request data available, i.e. a cron job for sending emails,
         // which requires Yii::app()->controller->createUrl
