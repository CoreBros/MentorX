<?php
$appName = '[[site_name]]';
$email = '[[admin_email]]';
$host = '[[softdbhost]]';
$user = '[[softdbuser]]';
$pass = '[[softdbpass]]';
$dbname = '[[softdb]]';
$version = '7.1';
$buildDate = 1548456424;
$updaterVersion = '6.9.1';
$language='en';
?>