<?php
$db_tiki='mysqli';
$dbversion_tiki='18.4';
$host_tiki='[[softdbhost]]';
$user_tiki='[[softdbuser]]';
$pass_tiki='[[softdbpass]]';
$dbs_tiki='[[softdb]]';
$client_charset='utf8';
// $dbfail_url = '';
// $noroute_url = './';
// If you experience text encoding issues after updating (e.g. apostrophes etc showing up as strange characters) 
// $client_charset='latin1';
// $client_charset='utf8';
// See http://tiki.org/ReleaseNotes5.0#Known_Issues and http://doc.tiki.org/Understanding+Encoding for more info

// If your php installation does not not have pdo extension
// $api_tiki = 'adodb';

// Want configurations managed at the system level or restrict some preferences? http://doc.tiki.org/System+Configuration
// $system_configuration_file = '/etc/tiki.ini';
// $system_configuration_identifier = 'example.com';

