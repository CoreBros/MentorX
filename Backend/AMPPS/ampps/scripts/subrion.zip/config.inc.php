<?php
/*
 * Subrion Open Source CMS 4.2.1
 * Config file generated on [[reg_time]]
 */

define('INTELLI_CONNECT', 'mysqli');
define('INTELLI_DBHOST', '[[softdbhost]]');
define('INTELLI_DBUSER', '[[softdbuser]]');
define('INTELLI_DBPASS', '[[softdbpass]]');
define('INTELLI_DBNAME', '[[softdb]]');
define('INTELLI_DBPORT', '3306');
define('INTELLI_DBPREFIX', '[[dbprefix]]');

define('IA_SALT', '[[IA_SALT]]');

// debug mode: 0 - disabled, 1 - enabled
define('INTELLI_DEBUG', 0);

