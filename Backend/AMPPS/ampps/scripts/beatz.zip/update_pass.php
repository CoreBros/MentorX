<?php

$algorithm = "sha1md5";

if (function_exists('hash_algos')) {
	$algos = hash_algos();
	if (in_array('sha512', $algos) && in_array('whirlpool', $algos)) {
		$algorithm = 'sha512whirlpool';
	} elseif (in_array('sha512', $algos)) {
		$algorithm = 'sha512';
	}
}

$password = "[[admin_pass]]";
$password .= "[[salt]]";

if ($algorithm == 'sha1md5') {
	$resp = sha1(md5($password));
} elseif ($algorithm == 'sha512whirlpool') {
	$resp = hash('sha512', hash('whirlpool', $password));
} elseif ($algorithm == 'sha512') {
	$resp = hash('sha512', $password);
}

echo '<update_pass>'.$resp.'</update_pass>';
echo '<algorithm>'.$algorithm.'</algorithm>';
@unlink('update_pass.php');