<?php return array (
  'components' => 
  array (
    'db' => 
    array (
      'connectionString' => 'mysql:host=[[softdbhost]];dbname=[[softdb]]',
      'username' => '[[softdbuser]]',
      'password' => '[[softdbpass]]',
    ),
    'cache' => 
    array (
      'class' => 'CFileCache',
    ),
    'user' => 
    array (
    ),
    'mail' => 
    array (
      'class' => 'ext.yii-mail.YiiMail',
      'transportType' => 'php',
      'viewPath' => 'application.views.mail',
      'logging' => true,
      'dryRun' => false,
    ),
  ),
  'params' => 
  array (
    'installer' => 
    array (
      'db' => 
      array (
        'installer_hostname' => '[[softdbhost]]',
        'installer_database' => '[[softdb]]',
      ),
    ),
    'installed' => true,
  ),
  'name' => '[[site_name]]',
  'language' => 'en',
  'theme' => 'construction_yii_theme',
); ?>