<?php
        $clarolineVersion = "[[claroversion]]";
        $versionDb = "[[claroversion]]";
        ?>