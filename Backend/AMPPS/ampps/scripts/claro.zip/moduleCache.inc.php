<?php #auto created by claroline modify it at your own risks
if (count( get_included_files() ) == 1) die();

# ---- start of cache ----


