.htaccess
bolt-public
extensions
files
index.php
theme
thumbs