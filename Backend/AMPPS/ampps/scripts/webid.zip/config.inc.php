<?php
$DbHost	 = "[[softdbhost]]";
$DbDatabase = "[[softdb]]";
$DbUser	 = "[[softdbuser]]";
$DbPassword = "[[softdbpass]]";
$DBPrefix	= "[[dbprefix]]";
$main_path = "[[softpath]]/";
$MD5_PREFIX = "[[md5_prefix]]";
?>