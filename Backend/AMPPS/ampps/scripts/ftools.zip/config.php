<?php

// main program paths - no trailing slashes!
$g_root_url = "[[softurl]]";
$g_root_dir = "[[softpath]]";

// database settings
$g_db_hostname = "[[softdbhost]]";
$g_db_port = "3306";
$g_db_name = "[[softdb]]";
$g_db_username = "[[softdbuser]]";
$g_db_password = "[[softdbpass]]";
$g_table_prefix = "[[dbprefix]]";

?>
