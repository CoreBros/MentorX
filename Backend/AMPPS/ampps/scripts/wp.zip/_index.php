<?php

echo 'softaculous_htaccess';

@unlink(__FILE__);

?>