<?php
$CONFIG = array (
  'instanceid' => '[[instanceid]]',
  'passwordsalt' => '[[passwordsalt]]',
  'secret' => '[[secret]]',
  'trusted_domains' => 
  array (
    0 => '[[domhost]]',
  ),
  'datadirectory' => '[[softdatadir]]',
  'dbtype' => 'mysql',
  'version' => '17.0.1.1',
  'overwrite.cli.url' => '[[softurl]]',
  'dbname' => '[[softdb]]',
  'dbhost' => '[[softdbhost]]',
  'dbport' => '',
  'dbtableprefix' => 'oc_',
  'dbuser' => '[[softdbuser]]',
  'dbpassword' => '[[softdbpass]]',
  'installed' => true,
);
