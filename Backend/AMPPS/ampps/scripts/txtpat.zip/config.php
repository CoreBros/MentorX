<?php
$txpcfg['db'] = '[[softdb]]';
$txpcfg['user'] = '[[softdbuser]]';
$txpcfg['pass'] = '[[softdbpass]]';
$txpcfg['host'] = '[[softdbhost]]';
$txpcfg['table_prefix'] = '[[dbprefix]]';
$txpcfg['txpath'] = '[[softpath]]/textpattern';
$txpcfg['dbcharset'] = 'utf8mb4';
?>
