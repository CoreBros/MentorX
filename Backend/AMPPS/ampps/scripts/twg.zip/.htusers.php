<?php
	/** ensure this file is being included by a parent file */
	defined( "_VALID_TWG" ) or die( "Direct Access to this location is not allowed." );
	$GLOBALS["users"]=array(
	array("[[admin_username]]","[[admin_pass]]",".","15",1,"",7,1),
); ?>