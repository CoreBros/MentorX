<?php

// Relative path to the installation
return '[[relativeurl]]';
