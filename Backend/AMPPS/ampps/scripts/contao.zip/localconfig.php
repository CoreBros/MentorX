<?php

### INSTALL SCRIPT START ###
$GLOBALS['TL_CONFIG']['licenseAccepted'] = true;
$GLOBALS['TL_CONFIG']['installPassword'] = '[[installtool_pass]]';
$GLOBALS['TL_CONFIG']['encryptionKey'] = '[[encryption_key]]';
$GLOBALS['TL_CONFIG']['dbDriver'] = 'MySQLi';
$GLOBALS['TL_CONFIG']['dbHost'] = '[[softdbhost]]';
$GLOBALS['TL_CONFIG']['dbUser'] = '[[softdbuser]]';
$GLOBALS['TL_CONFIG']['dbPass'] = '[[softdbpass]]';
$GLOBALS['TL_CONFIG']['dbDatabase'] = '[[softdb]]';
$GLOBALS['TL_CONFIG']['dbPconnect'] = false;
$GLOBALS['TL_CONFIG']['dbCharset'] = 'UTF8';
$GLOBALS['TL_CONFIG']['dbPort'] = 3306;
$GLOBALS['TL_CONFIG']['dbSocket'] = '';
$GLOBALS['TL_CONFIG']['adminEmail'] = '[[admin_email]]';
$GLOBALS['TL_CONFIG']['latestVersion'] = '3.5.40';
$GLOBALS['TL_CONFIG']['maintenanceMode'] = false;
### INSTALL SCRIPT STOP ###
