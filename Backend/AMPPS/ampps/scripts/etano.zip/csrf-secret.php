<?php $secret = "[[secret]]";
