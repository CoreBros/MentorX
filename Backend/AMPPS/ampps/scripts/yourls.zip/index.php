<?php
include_once('admin/index.php')
?>