<?php
$db_host = '[[softdbhost]]';

$db_name = '[[softdb]]';

$db_user = '[[softdbuser]]';

$db_pass = '[[softdbpass]]';

$db_driver = 'mysql';

?>