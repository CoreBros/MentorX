<?php
$authentication['LOGINS']['[[admin_username]]'] = '[[admin_pass]]';
?>